//------------------------------------------------------------------//
// Author: Qian LIU
// Modified by MengZhi Wu
//------------------------------------------------------------------//


#include <iostream>
#include <fstream>
#include <cmath>

#include <TApplication.h>
#include <TCanvas.h>
#include <TH1F.h>
#include <TGeoManager.h>
#include <TGeoMaterial.h>
#include <TGeoMedium.h>
#include <TGeoVolume.h>
#include <TGeoBBox.h>
#include <TGeoTube.h>
#include <TGeoPcon.h>
#include <TGeoHalfSpace.h>
#include <TGeoMatrix.h>
#include <TGeoCompositeShape.h>
#include <TGraph.h>
#include <TFile.h>
#include <TMath.h>

#include "ComponentComsol.hh"
#include "ViewField.hh"
#include "ViewFEMesh.hh"
#include "MediumMagboltz.hh"
#include "Sensor.hh"
#include "AvalancheMicroscopic.hh"
#include "AvalancheMC.hh"
#include "Random.hh"
#include "Plotting.hh"
#include "ViewSignal.hh"

#include <time.h>
using namespace Garfield;
using namespace std;

void ReadFiledMap(TString);
void DefineGas(const char *gas1, double rat1, const char *gas2, double rat2, const char *filename);
void PlotField(ComponentComsol* fm);
void PlotDriftLine(AvalancheMC* drift, ViewDrift* driftView);

ComponentComsol *fm;
MediumMagboltz    *gas;

// Dimensions of the GEM, in !!!! CM !!!!, note that in Ansys it's in MM !
const double pitch  = 0.1;
const double kapton = 0.04;
const double metal  = 0.001;
const double diamup = 0.06;
const double diamdown = 0.04;
const double induct = 0.2;
const double driftdown  = 0.3;
const double driftup  = 0.3;

// Dimensions for area selection for DriftView & Sensor etc.
const double xmin = -pitch*3/2;
const double xmax =  pitch*3/2;
const double ymin = -pitch*3/2;
const double ymax =  pitch*3/2;
const double zmin =  0;
const double zmax =  induct+driftdown+driftup+2*kapton+4*metal;

char Path[100] = "./";
TString RootFile = TString(Path)+TString("/result.root");
//------------------------------------------------------------------//
// Main
//------------------------------------------------------------------//
int main(int argc, char * argv[]) {
    
    TApplication app("app", &argc, argv);
    plottingEngine.SetDefaultStyle();
    
    // Control flag
    const bool debug = true;
    const bool plotField = false;
    const bool plotDrift = true; 
    const bool plotDriftLine = false;
    const bool plotEFDrift = true;

    //const bool plotGeo = false;
    const bool plotHistogram = true;
    const bool plotGain = true;
    
    //the prim ionization Z pozition. Now I set it to induction field to study IONs!!
    //const double zprim  = induct-0.05;
    //const double zprim = 0.2;
    
	const double tStart =0;
	const double tStop =100;
	const int nSteps =100;
	const double tStep =(tStop - tStart) /nSteps;
	const std::string label = "readout";
    
    //-----------------------------
    // Start simulation
    ReadFiledMap(TString(Path));
    
    DefineGas("argon", 90, "isopropanol", 10,"Ar-iC4H10(90-10).gas");
    
    //---------------------------------------------------------------
    //!!!!! AT LEAST RUN THIS ONCE TO CHECK THE ELECTRIC FIELD !!!!!!
    //!!!!!           IS CORRECTLY SIMULATED BY ANSYS          !!!!!!
    //---------------------------------------------------------------
    // for example, check the anode Z position and potential.
    if(plotField) {PlotField(fm); app.Run(kTRUE);}
    cout << "111" << endl; 
	//fm->SetWeightingField("WPOT.lis", label);
    //------------------------------------------------------
    // Create the sensor. Initialize
    Sensor* sensor = new Sensor();
    sensor->AddComponent(fm);
	//sensor->AddElectrode(fm, label);
	sensor->SetTimeWindow(-1, tStep, 200);
    //sensor->SetArea(-truepitch, -truepitch, zmin, truepitch, truepitch, zmax);	// create a sensor area
    
    sensor->SetArea(xmin, ymin, zmin, xmax, ymax, zmax);
	sensor->ClearSignal();
	//sensor->EnableDebugging();
    //------------------------------------------------------
    // Now avalanche and track electron
    AvalancheMicroscopic* aval = new AvalancheMicroscopic();
    aval->SetSensor(sensor);
	aval->EnableSignalCalculation();
    // Now track ions
    AvalancheMC* drift = new AvalancheMC();
    drift->SetSensor(sensor);
    drift->SetDistanceSteps(2.e-4);
    
    //------------------------------------------------------
    // plot drift line.
    ViewDrift* driftView = new ViewDrift();
    if (plotDrift) {
        driftView->SetArea(xmin, ymin, zmin, xmax, ymax, zmax);
        // Plot every 10 collisions (in microscopic tracking).
        aval->SetCollisionSteps(10);
        aval->EnablePlotting(driftView);
        drift->EnablePlotting(driftView);
	 
        if(plotDriftLine) { PlotDriftLine(drift, driftView); app.Run(kTRUE);}
    }
  


    //------------------------------------------------------
    // define Histograms according to your needs
    int nBinsGain = 50;
    double gmin =   0.;
    double gmax = 500.;
    TH1F* hElectrons = new TH1F("hElectrons", "Number of electrons", nBinsGain, gmin, gmax);
    TH1F* hIons      = new TH1F("hIons",      "Number of ions",      nBinsGain, gmin, gmax);
    TH1F* hGain      = new TH1F("hGain", "Absolute Gain", nBinsGain, gmin, gmax);
    TH1F* hEffGain = new TH1F("hEffGain", "Effective Gain", nBinsGain, gmin, gmax);
    
    int nBinsChrg = 100;
    TH1F* hChrgE = new TH1F("hChrgE", "Electrons on plastic", nBinsChrg, -0.5e4 * kapton, 0.5e4 * kapton);
    TH1F* hChrgI = new TH1F("hChrgI", "Ions on plastic", nBinsChrg, -0.5e4 * kapton, 0.5e4 * kapton);
	TH1F* hVeloc = new TH1F("hVeloc", "velocity of electron", 100, gmin, 100);
	TH2F* hposi = new TH2F("hposi", "position of electron", 100, xmin, xmax, 100, ymin, ymax);
	//TH1F* hYposi = new TH1F("hYposi", "y position of electron", 100, ymin, ymax);
    TGraph* hElecZpos = new TGraph();
    TGraph* hIonZpos  = new TGraph();
    TGraph* hIonCath= new TGraph();
    TGraph* hIonTHGEMup= new TGraph();
    //TGraph* hIonKap= new TGraph();
    TGraph* hIonTHGEMdown= new TGraph();
    hElecZpos->SetName("hElecZpos");
    hIonZpos->SetName("hIonZpos");
    hIonCath->SetName("hIonCath");
    hIonTHGEMup->SetName("hIonTHGEMup");
    //hIonKap->SetName("hIonKap");
    hIonTHGEMdown->SetName("hIonTHGEMdown");
    
    double sumIonsTotal = 0.;
    double sumIonsDrift = 0.;

    //--------------------------
    // written by wmz
    double sumIonsBackFlow = 0.;
    double sumIonsTHGEMup = 0.;
    double sumIonsTHGEMdown = 0.;
    double sumIonsOther = 0.;

    double sumElectronsTHGEMup = 0.;
    double sumElectronsTHGEMdown = 0.;
    //-------------------------

    double sumElectronsTotal = 0.;
    double sumElectronsTransfer = 0.;
    double sumElectronsOther = 0.;
    
    // -----------------------------------------------
    // Define things to obtain the detection effeciency
    bool FindElectron = false;
    double singleElectronGain=0.;
    double singleElectronAnode=0.;
    double nDetects=0.;
    //-----------------------------------------------


    //------------------------------------------------------
    // Start to do the simulation.
    //------------------------------------------------------
    // The goal of this simulation is to study the ion transparency through THGEM.
    // So the ions are put at induction field, so they can drift upwards.
    // In garfield I haven't figured out how to put ions sperately, so I put electrons.
    // When an electron is put, an ion is also generated in pires, that's how I got ions done.
    //------------------------------------------------------
    const int nEvents   = 10000;
	clock_t start, stop;
    start = clock();
    for (int i = nEvents; i--;) {
        if (debug && i%100==0) std::cout << i << "/" << nEvents << "\n";
        // Randomize the initial position x0
		double xsmear = diamdown/2 ;
        double x0 = - xsmear + 2*RndmUniform() * xsmear;
        double ysmear = diamdown/2 ;
        double y0 = - ysmear + 2*RndmUniform() * ysmear;
		//double x0 = 0.;
        //double y0 = 0.;
        double z0 = induct - RndmUniform() * 0.08;
        double t0 = 0.;
        double e0 = 0.1;
	    
        int ne = 0, ni = 0;  //ne, ni represents the number of electrons and ions
        
        aval->DriftElectron(x0, y0, z0, t0, e0, 0., 0., 0.);	// Calculate an electron avalanche
	    aval->GetAvalancheSize(ne, ni);

        //std::cout<<"Avalance "<<i<<" - electrons = "<<ne<<", ions = "<<ni<<"\n";
        hElectrons->Fill(ne);
        hIons->Fill(ni);
        const int np = aval->GetNumberOfElectronEndpoints();
        double xe1, ye1, ze1, te1, e1;
        double xe2, ye2, ze2, te2, e2;
        double xi1, yi1, zi1, ti1;
        double xi2, yi2, zi2, ti2;
        int status;

        FindElectron = false;
        singleElectronGain = np;
        singleElectronAnode = 0.;

	    //-------------------------------------------------------------------
	    // Collect the endpoints information of Electrons and Ions
        // written by wmz
        // The situation of Electrons
        for (int j = np; j--;) {
            aval->GetElectronEndpoint(j, xe1, ye1, ze1, te1, e1,
                                      xe2, ye2, ze2, te2, e2, status);
            hElecZpos->SetPoint(int(sumElectronsTotal), xe2 * 1.e4, ze2 * 1.e4);
            sumElectronsTotal += 1.;
            if (ze2 >= induct+driftdown+kapton+metal*2 && ze2 <= induct+driftdown+kapton*2+metal*4) {
                hChrgE->Fill(ze2 * 1.e4);
		        sumElectronsTHGEMup += 1.;
            } else if (ze2 >= induct && ze2 <= induct+kapton+metal*2) {
                sumElectronsTHGEMdown += 1.;
            } else if (ze2 < induct) {
                sumElectronsTransfer += 1.;
                FindElectron = true;
                singleElectronAnode += 1.;
            } else {
                sumElectronsOther += 1.;
            }
	
	        // Debug log (wmz)
	        //     wmz once placed drift->DriftIon(balabala) before for(balabla){aval->GetElectronEndpoint(balabala); balabala}
	        //     and the consequence was that there was no ion produced
	        //     it is because drift->DriftIon(balabala) is based on aval->GetElectronEndpoint(balabala)

            drift->DriftIon(xe1, ye1, ze1, te1);
            drift->GetIonEndpoint(0, xi1, yi1, zi1, ti1,
                                  xi2, yi2, zi2, ti2, status);
	        // The situation of Ions
	        hIonZpos->SetPoint(int(sumIonsTotal), xi2 * 1.e4, zi2 * 1.e4);
	        sumIonsTotal += 1.;
	        if(zi2 > induct+driftdown+kapton*2+metal*4) { 	
		        hIonCath->SetPoint(sumIonsBackFlow++, xi2 * 1.e4, zi2 * 1.e4);
	        } else if(zi2 >= induct+driftdown+kapton+metal*2-0.01 && zi2 <= induct+driftdown+kapton*2+metal*4+0.01) {
                hIonTHGEMup ->SetPoint( sumIonsTHGEMup ++, xi2 * 1.e4, zi2 * 1.e4);
	        } else if(zi2 >= induct-0.01 && zi2<=induct+kapton+metal*2+0.01) {
		        hIonTHGEMdown->SetPoint(sumIonsTHGEMdown ++, xi2 * 1.e4, zi2 * 1.e4);
	        } else {
		        sumIonsOther += 1.;
	        }
	        //-------------------------------------------------------------------

			//std::cout<<"end z is "<<ze2<<" timestart "<<te1<<" tend "<<te2<<" energy "<<e2<<std::endl;
			double velocity = sqrt(pow(ze2-ze1,2)+pow(ye2-ye1,2)+pow(xe2-xe1,2))/(te2-te1)*10000;
			hVeloc->Fill(velocity);
			if (ze2 <= -0.4){
			    //std::cout<<xe2<<ye2<<std::endl;
			    hposi->Fill(xe2, ye2, e2);
			}
			//std::cout<<velocity<<std::endl;

        } // End of the "for" loop of one event!
        
        if(FindElectron) {
            nDetects += 1.;
            hEffGain->Fill(singleElectronAnode);
        }
        hGain->Fill(singleElectronGain);

    } // End of the "for" loop of all events!
	

    //-------------------------------------------------------------
    // Print the Statistical results of Electrons and Ions  
    // written by wmz
    double fDetect = 0.;
    double fFeedback = 0.;
    if (nEvents>0) fDetect = nDetects / nEvents;
    if (sumIonsTotal > 0.) fFeedback = sumIonsDrift / sumIonsTotal;
    std::cout << "Number of detection: " << nDetects << "\n";
    std::cout << "Detection efficiency: " <<  fDetect << "\n";
    std::cout << "Fraction of ions drifting back: " << fFeedback << "\n";
    const double neMean = hElectrons->GetMean();
    const double niMean = hIons->GetMean();
    const double AbsGain = hGain->GetMean();
    const double EffGain=hEffGain->GetMean();
    std::cout << "Mean number of electrons: " << neMean << "\n";
    std::cout << "Mean number of ions: " << niMean << "\n";
    std::cout << "Absolute gain: " << AbsGain << "\n";
    std::cout << "Effective gain: " << EffGain << "\n";

    const double fIonsBack = sumIonsBackFlow / sumIonsTotal;
    const double fIonsOther = sumIonsOther / sumIonsTotal;
    const double fIonsTHGEMup = sumIonsTHGEMup / sumIonsTotal;
    const double fIonsTHGEMdown = sumIonsTHGEMdown / sumIonsTotal;

    const double fElectronsTransfer = sumElectronsTransfer / sumElectronsTotal;
    const double fElectronsOther = sumElectronsOther / sumElectronsTotal;
    const double fElectronsTHGEMup = sumElectronsTHGEMup / sumElectronsTotal;
    const double fElectronsTHGEMdown = sumElectronsTHGEMdown /sumElectronsTotal;

    std::cout << "Electron endpoints:\n";
    std::cout << "    transfer:    " << fElectronsTransfer * 100. << "%\n";
    std::cout << "    THGEMup:     " << fElectronsTHGEMup * 100. << "%\n";   
    std::cout << "    THGEMdown:   " << fElectronsTHGEMdown * 100. << "%\n";
    std::cout << "    other:       " << fElectronsOther * 100. << "%\n";

    std::cout << "Ion endpoints:\n";
    std::cout << "    Ion Back Flow:     " << fIonsBack * 100. << "%\n";
    std::cout << "    THGEMup:           " << fIonsTHGEMup * 100. << "%\n";
    std::cout << "    THGEMdown:         " << fIonsTHGEMdown * 100. << "%\n";
    std::cout << "    other:             " << fIonsOther * 100. << "%\n";
    
    //-------------------------------------------------------------


    TFile *f = new TFile(RootFile.Data(), "recreate");
    f->cd();
	
    hElectrons->Write();
    hIons->Write();
    hChrgE->Write();
    hChrgI->Write();
	hVeloc->Write();
	hposi->Write();
	//hYposi->Write();
    hElecZpos->Write();
    hIonZpos->Write();
    hIonCath->Write();
    hIonTHGEMup->Write();
    //hIonKap->Write();
    hIonTHGEMdown->Write();
    hEffGain->Write();
    f->Close();
    
	stop = clock();
    cout<<" Time consuming: "<<(double)(stop - start)/CLOCKS_PER_SEC<<endl;
    TCanvas* cD = new TCanvas();
    if (plotDrift) {
        driftView->SetCanvas(cD);
        driftView->Plot();
        cD->SaveAs("eps/Diffusion.eps");
        if (plotEFDrift) {
            ViewFEMesh* meshView = new ViewFEMesh();
            meshView->SetComponent(fm);
            meshView->SetPlane(0., -1, 0., 0., 0., 0.);
			meshView->SetArea(xmin, zmin, zmin, xmax, zmax, zmax);
			//std::cout<<"it come in "<<std::endl;
            meshView->SetFillColor(2,3); //matid=2 is FR4, painted as green.
			//std::cout<<"it come in 2 "<<std::endl;
            meshView->SetFillMesh(true);
			//std::cout<<"it come in 3 "<<std::endl;
            meshView->SetViewDrift(driftView);
			//std::cout<<"it come in 4"<<std::endl;
            TCanvas* cM = new TCanvas();
            meshView->SetCanvas(cM);
            meshView->Plot();

	    cM->SaveAs("eps/DriftLine.eps");
        }
    }
    
    if (plotHistogram) {
        TCanvas* cH = new TCanvas("cH", "Histograms", 800, 700);
        cH->Divide(2, 2);
        cH->cd(1);
        hElecZpos->SetMarkerSize(0.5);
        hElecZpos->SetMarkerStyle(8);
        hElecZpos->Draw("ap");
        hElectrons->Draw();
        cH->cd(2);
        hIons->Draw();
        cH->cd(3);
        hChrgE->Draw();
        cH->cd(4);
        hChrgI->Draw();
	cH->SaveAs("eps/Histogram.eps");
    }

    if(plotGain){
        TCanvas* cG = new TCanvas("cG","Histograms",800,700);
        cG->Divide(1,2);
        cG->cd(1);
        hGain->Draw();
        cG->cd(2);
        hEffGain->Draw();
    }
    
    app.Run(kTRUE);
}


//------------------------------------------------------------------//
// Read COMSOL 5.3a or 5.4 output
//------------------------------------------------------------------//
void ReadFiledMap(TString path)
{
    std::cout<<" Entering "<<path<<std::endl;
    // Load the field map.
	fm = new ComponentComsol();
    TString mfile = path+TString("/dat/Mesh700-800.mphtxt");
    TString dfile = path+TString("/dat/dielectrics_article.dat");
    TString ffile = path+TString("/dat/Field700-800.txt");

    fm->Initialise(mfile.Data(), dfile.Data(), ffile.Data());
    fm->EnablePeriodicityX();
    fm->EnablePeriodicityY();
	fm->SetMagneticField(0.,0.,0.);
    fm->PrintRange();				// print some information about the cell dimention
}

//------------------------------------------------------------------//
// define gas compounents
//------------------------------------------------------------------//
void DefineGas(const char *gas1, double rat1, const char *gas2, double rat2, const char *filename)
{

    gas = new MediumMagboltz();

    cout<<"?"<<endl;

    if(!gas->LoadGasFile(filename)) 
    {
        gas->SetComposition(gas1, rat1, gas2, rat2);
        //gas->SetComposition(gas1, rat1);
        gas->SetTemperature(293.15);
        gas->SetPressure(760);  //In Huang XueFeng's work, he uses 0.8atm=0.8*760mmHg gas-pressure
        gas->EnableDebugging();
        gas->Initialise();
        gas->DisableDebugging();
        
        gas->SetMaxElectronEnergy(200.); //eV
        gas->SetMaxPhotonEnergy(200.);
        gas->EnableEnergyRangeAdjustment(true);
        gas->EnableAnisotropicScattering();
        
        gas->Initialise(true);
        // Set the Penning transfer efficiency.
        const double rPenning = 0.57;
        const double lambdaPenning = 0.;
        gas->EnablePenningTransfer(rPenning, lambdaPenning, "ar");
        // Generate the gas table file for electron drift
        gas->GenerateGasTable(1,false);
	    gas->WriteGasFile(filename);
    }
    // Load the ion mobilities
    gas->LoadIonMobility("/home/thomas/HEPsoftwares/build/garfieldpp/Data/IonMobility_Ar+_Ar.txt");	
	
    double ex;
	double vx, vy, vz;
	double dl, dt;
	double alpha; 
	double eta;

	for(int i=1; i<100; i++)
	{
	    ex = i*10;
	    gas->ElectronVelocity  (ex, 0, 0, 0, 0, 0, vx, vy, vz);
            gas->ElectronDiffusion (ex, 0, 0, 0, 0, 0, dl, dt);
            gas->ElectronTownsend  (ex, 0, 0, 0, 0, 0, alpha);
            gas->ElectronAttachment(ex, 0, 0, 0, 0, 0, eta);

	    cout<<"E = "<<ex<<"V/cm,   Vx ="<<vx*1000<<"cm/us; alpha = "<<alpha<<"/cm"<<endl;
        }

    cout << "OK" << endl;
    // Associate the gas with the corresponding field map material.
    const int nMaterials = fm->GetNumberOfMaterials();
    for (int i = 0; i < nMaterials; ++i) {
        const double eps = fm->GetPermittivity(i);	 	// Get permittivity (episilon)
        if (fabs(eps - 1.) < 1.e-3) fm->SetMedium(i, gas);	// set gas as medium if eps is arround 1
    }

}


//------------------------------------------------------------------//
// 画电场，电力线等图
//------------------------------------------------------------------//
void PlotField(ComponentComsol* fm)
{
    
    ViewField* fieldView = new ViewField();
    fieldView->SetComponent(fm);
    
    fieldView->SetNumberOfSamples1d(2000); 	      //default is 1000, the density of the plotting grid
    fieldView->SetNumberOfSamples2d(100,100);	      //default is 200, 200. 二维图的nX, nY
    fieldView->SetNumberOfContours(50); 	      //default is 100, 等高线的次数
    //fieldView->SetVoltageRange(-3000., 3000.);    //the min/max of potential in the Component is used as default, but it can also be defined by user.
    //fieldView->SetElectricFieldRange(0,20000);	  //default is (0, 100). it must be defined by user for electric field.
    //fieldView->SetWeightingFieldRange(0,10);	  //it must be defined by user for weighting field.

     //fieldView->SetPlane(0.866, -0.5, 0., 0., 0., 0.);	      //(fx,fy,fz,x0,y0,z0), (fx,fy,fz) 指定的是平面的法线方向。
/*	fieldView->SetPlane(0, -1, 0, 0., 0., 0.);	
     //fieldView->Rotate(TMath::Pi()*3./2.);                     //指定切出来的平面，在做图的时候选择的角度。比如有时候出来的是Y:Z(Y是横轴，Z是纵轴），可以选择Pi/2来交换成Z:Y
   fieldView->SetArea(-pitch / 2., zmin, pitch / 2., zmax);  //指定这个平面所画的区域大小
    TCanvas* cF1 = new TCanvas();
    fieldView->SetCanvas(cF1);
    fieldView->PlotContour("v");                            // v/p/phi/volt/voltage/pot/potential 都是画电势, e/field 画电场, or ex/ey/ez         
*/
    fieldView->SetPlane(0, 0, 0, 0., 0., 0.2);
    cout << "OK" << endl;
    fieldView->SetArea(-pitch, -pitch, pitch, pitch);  //指定这个平面所画的区域大小
    TCanvas* cF2 = new TCanvas();
    fieldView->SetCanvas(cF2);
    fieldView->PlotContour("e"); 
    cF2->SaveAs("Field2.eps");

    TCanvas* cF3 = new TCanvas();
    fieldView->SetCanvas(cF3);
    fieldView->PlotProfile(0, 0, -1*(kapton/2+metal+induct), 0, 0, kapton/2+metal+driftdown+driftup, "v");
    cF3->SaveAs("Field3.eps");
    cout << "480" << endl; 
/*
    TCanvas* cF4 = new TCanvas();
    fieldView->SetCanvas(cF4);
    fieldView->PlotProfile(0, 0, -1*(kapton/2+metal+induct), 0, 0, kapton/2+metal+drift, "ex");

    TCanvas* cF5 = new TCanvas();
    fieldView->SetCanvas(cF5);
    fieldView->PlotProfile(0, 0, -1*(kapton/2+metal+induct), 0, 0, kapton/2+metal+drift, "ey");
   
    TCanvas* cF6 = new TCanvas();
    fieldView->SetCanvas(cF6);
    fieldView->PlotProfile(0, 0, -1*(kapton/2+metal+induct), 0, 0, kapton/2+metal+drift, "ez");

    */
    return;
    
}


//------------------------------------------------------------------//
// Plot drift lines
//------------------------------------------------------------------//
void PlotDriftLine(AvalancheMC* drift, ViewDrift* driftView)
{ 
    drift->DisableDiffusion();
    const int Nbin=50;
    for(int i=0;i<=Nbin;i++) {  
        double xtmp = xmin+i*(xmax-xmin)/Nbin;
        drift->DriftIon(xtmp,0,zmin,0);
        //   drift->DriftIon(xtmp,0,-0.0120,0);
    }
    
    TCanvas* cD = new TCanvas();
    driftView->SetCanvas(cD);
    driftView->Plot();
     
    ViewFEMesh* meshView = new ViewFEMesh();
    meshView->SetComponent(fm);
    meshView->SetPlane(0., -1, 0., 0., 0., 0.);
    meshView->SetArea(xmin, ymin, zmin, xmax, ymax, zmax);
    meshView->SetFillColor(2,3); //matid=2 is FR4, painted as green.
    meshView->SetFillMesh(true);  
    meshView->SetViewDrift(driftView);
    TCanvas* cM = new TCanvas();
    meshView->SetCanvas(cM); 
    meshView->Plot();

    cD->SaveAs("DriftLine.eps");
    cM->SaveAs("Mesh.eps");
}

