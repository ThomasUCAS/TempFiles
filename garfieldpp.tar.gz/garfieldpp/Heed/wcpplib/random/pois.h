#ifndef POIS_H
#define POIS_H

namespace Heed {

long pois(const double amu, int &ierror);
}

#endif
